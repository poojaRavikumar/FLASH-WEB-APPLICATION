from flask import Flask, render_template, request, redirect, url_for, flash

app = Flask(__name__)
app.secret_key = 'supersecretkey'  # Required for flash messages

# Dummy data for user authentication
users = {
    "testuser": "password"  # Simple username/password for demonstration
}

def welcome():
    return "<h1>Welcome to the Flask Application!</h1><p>This is the welcome page.</p>"

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        # Basic check for username and password
        if username in users and users[username] == password:
            flash('Login successful!', 'success')
            return redirect(url_for('dashboard'))
        else:
            flash('Invalid credentials, please try again.', 'danger')
            return redirect(url_for('login'))
    
    # Render the login form on GET request
    return render_template('login.html')

@app.route('/')
def dashboard():
    return "<h1>Welcome to the IFT 510 Fall 2024! 480-8890</h1>"

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
